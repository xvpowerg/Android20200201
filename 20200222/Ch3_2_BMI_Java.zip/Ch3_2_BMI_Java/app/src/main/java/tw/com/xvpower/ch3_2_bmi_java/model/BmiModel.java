package tw.com.xvpower.ch3_2_bmi_java.model;

import tw.com.xvpower.ch3_2_bmi_java.R;

public class BmiModel {
    private float height;
    private float weight;
    private double bmi = -1;

    public BmiModel(String height,String weight){
         this( Float.parseFloat(height),Float.parseFloat(weight));

    }
    public BmiModel(float height,float weight){
        this.height = height;
        this.weight = weight;
    }

    public double calculatBMI(){
        height /= 100;
        bmi =weight/Math.pow(height,2);
        return  bmi;
    }

    public int getBMIStatusResourceId(){
        if (bmi < 20){
            return R.string.bmi_low;
        }else if(bmi < 26){
            return R.string.bmi_normal;
        }else if (bmi < 30){
            return R.string.bmi_mild_obesity;
        }else if(bmi < 40){
            return R.string.bmi_moderate_obesity;
        }else if(bmi <= 100){
            return R.string.bmi_height_obesity;
        }else{
            return R.string.bmi_over_height_obesity;
        }
    }
}
