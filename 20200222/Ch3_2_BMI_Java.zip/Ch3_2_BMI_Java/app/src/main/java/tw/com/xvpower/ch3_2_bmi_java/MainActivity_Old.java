package tw.com.xvpower.ch3_2_bmi_java;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity_Old extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final EditText heightEDT =  findViewById(R.id.heightEDT);//假設為公分
       final EditText weightEDT = findViewById(R.id.weightEDT);
       final Button btn = findViewById(R.id.calBmiBtn);
       final TextView bmiText = findViewById(R.id.bmiText);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //1 把公分轉公尺 / 100
                //BMI 公式 = weightEDT / heightEDT(公尺) ^ 2
               String heightStr =  heightEDT.getText().toString();
               String weightStr =  weightEDT.getText().toString();
               float height =  Float.parseFloat(heightStr);
                height /= 100;//公分轉公尺
               float weight = Float.parseFloat(weightStr);
               double bmi = weight/Math.pow(height,2);

                // 小於 20 過輕
                // 小於 26 正常
                // 小於 30 輕度肥胖
                // 小於 40　中度肥胖
                // 小於等於 100　高度肥胖
                // 大於　100　重度肥胖
                String msg = "";
                 if (bmi < 20){
                     msg = getString(R.string.bmi_low);
                 }else if(bmi < 26){
                     msg = getString(R.string.bmi_normal);
                 }else if (bmi < 30){
                     msg = getString(R.string.bmi_mild_obesity);
                 }else if(bmi < 40){
                     msg = getString(R.string.bmi_moderate_obesity);
                 }else if(bmi <= 100){
                     msg = getString(R.string.bmi_height_obesity);
                 }else{
                     msg = getString(R.string.bmi_over_height_obesity);
                 }
                String bmiStr = String.format("BMI:%.2f 狀態:%s",bmi,msg);//取道小數點第二位 並且四捨五入
                bmiText.setText(bmiStr);

            }
        });

    }
}
