package tw.com.xvpower.ch3_2_bmi_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import tw.com.xvpower.ch3_2_bmi_java.model.BmiModel;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       final EditText heightEDT =  findViewById(R.id.heightEDT);//假設為公分
       final EditText weightEDT = findViewById(R.id.weightEDT);
       final Button btn = findViewById(R.id.calBmiBtn);
       final TextView bmiText = findViewById(R.id.bmiText);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 String heightStr =
                         heightEDT.getText().toString();
                 String weightStr =
                         weightEDT.getText().toString();
                BmiModel bmiModel =
                        new BmiModel(heightStr,weightStr);
                double bmi = bmiModel.calculatBMI();
                String msg =
                        getString(bmiModel.getBMIStatusResourceId());
                String bmiStr =
                        String.format("BMI:%.2f 狀態:%s",
                                bmi,msg);
                bmiText.setText(bmiStr);

            }
        });

    }
}
