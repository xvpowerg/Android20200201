package tw.com.xvpower.ch3_2_bmi_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*
import tw.com.xvpower.ch3_2_bmi_kotlin.model.BmiModel
fun TextView.toStr():String{
    return this.text.toString()
}
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        calBmiBtn.setOnClickListener {
            val heightStr=  heightEDT.toStr()
            val weightStr= weightEDT.toStr()
            val bmiModel = BmiModel(heightStr,weightStr)

           val msg =  "BMI:%.2f,Status:%s".
               format(bmiModel.calculatBMI(),
               getString(bmiModel.getBMIStatusResId())
                )
            bmiText.text = msg
        }

    }
}
