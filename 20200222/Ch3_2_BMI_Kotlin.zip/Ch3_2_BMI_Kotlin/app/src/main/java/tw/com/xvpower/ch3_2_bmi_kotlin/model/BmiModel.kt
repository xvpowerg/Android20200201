package tw.com.xvpower.ch3_2_bmi_kotlin.model

import tw.com.xvpower.ch3_2_bmi_kotlin.R
import kotlin.math.pow

class BmiModel(var height:Double,val weight:Float) {
    private var bmi:Double = -1.0
    //Overloading 建構子
    constructor(height:String,weight:String):
            this(height.toDouble(),weight.toFloat())

    fun calculatBMI():Double{
        height /= 100
        bmi = weight / height.pow(2)
        return bmi
    }


    fun getBMIStatusResId():Int{
        return when{
            bmi < 20 -> R.string.bmi_low
            bmi < 26 -> R.string.bmi_normal
            bmi < 40 ->  R.string.bmi_moderate_obesity
            bmi <= 100 -> R.string.bmi_height_obesity
            else -> R.string.bmi_over_height_obesity
        }

    }

}