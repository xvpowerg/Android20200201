package tw.com.xvpower.ch3_1_newactivity_kotlin

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class Page3Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.page3_activity_layout)
    }

}