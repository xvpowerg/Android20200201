package tw.com.xvpower.ch3_1_newactivity_kotlin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.page2_activity_layout.*

class Page2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.page2_activity_layout)
        val name=  intent.
            getStringExtra("name")
        showNameText.text = name
        toPage3Btn.setOnClickListener {
           val toPage3Intent =  Intent(this,
               Page3Activity::class.java)
           startActivity(toPage3Intent)
        }

        Log.d("AndoridLifecycle","Page2Activity onCreate")
    }

    override fun onRestart() {
        super.onRestart()

        Log.d("AndoridLifecycle","Page2Activity onRestart")
    }

    override fun onStart() {
        super.onStart()
        Log.d("AndoridLifecycle","Page2Activity onStart")
    }



    override fun onResume() {
        super.onResume()
        Log.d("AndoridLifecycle","Page2Activity onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("AndoridLifecycle","Page2Activity onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("AndoridLifecycle","Page2Activity onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("AndoridLifecycle","Page2Activity onDestroy")
    }


}