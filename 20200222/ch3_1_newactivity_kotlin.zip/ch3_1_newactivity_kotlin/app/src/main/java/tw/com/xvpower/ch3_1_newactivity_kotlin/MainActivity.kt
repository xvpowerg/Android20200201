package tw.com.xvpower.ch3_1_newactivity_kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.d("AndoridLifecycle","MainActivity onCreate")
        toPage2Btn.setOnClickListener {
            val toPage2Intent = Intent(this,
                Page2Activity::class.java)
            val name = nameEDT.text.toString()
            toPage2Intent.putExtra("name",name)
            startActivity(toPage2Intent)

        }
    }

    override fun onRestart() {
        super.onRestart()

        Log.d("AndoridLifecycle","MainActivity onRestart")
    }

    override fun onStart() {
        super.onStart()
        Log.d("AndoridLifecycle","MainActivity onStart")
    }



    override fun onResume() {
        super.onResume()
        Log.d("AndoridLifecycle","MainActivity onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("AndoridLifecycle","MainActivity onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("AndoridLifecycle","MainActivity onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("AndoridLifecycle","MainActivity onDestroy")
    }
}
