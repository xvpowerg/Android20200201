package tw.com.xvpower.ch3_2_bmi_activityresult_java;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView bmiText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText heightEDT =  findViewById(R.id.heightEDT);//假設為公分
        final EditText weightEDT = findViewById(R.id.weightEDT);
        final Button btn = findViewById(R.id.calBmiBtn);
        bmiText = findViewById(R.id.bmiText);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String heightStr =
                        heightEDT.getText().toString();
                String weightStr =
                        weightEDT.getText().toString();
                Intent toCalculatBMI = new Intent(
                        MainActivity.this,
                        CalculatBmiActivity.class);
                toCalculatBMI.putExtra("heightStr",heightStr);
                toCalculatBMI.putExtra("weightStr",weightStr);
            startActivityForResult(toCalculatBMI,500);
            }
        });

    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode,
                resultCode, data);

        String bmi_msg =
                data.getStringExtra(
                        "bmi_msg");
        bmiText.setText(bmi_msg);
        Log.d("Howard",
                "bmi_msg:"+bmi_msg);

    }
}
