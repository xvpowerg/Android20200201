package tw.com.xvpower.ch3_2_bmi_activityresult_java;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import tw.com.xvpower.ch3_2_bmi_activityresult_java.model.BmiModel;

public class CalculatBmiActivity  extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
           Intent data= getIntent();
         String heightStr =  data.getStringExtra("heightStr");
         String weightStr =  data.getStringExtra("weightStr");

        BmiModel bmiModel = new BmiModel(heightStr,weightStr);
       double bmi = bmiModel.calculatBMI();
       String status = getString(bmiModel.getBMIStatusResourceId());
       String msg = String.format("BMI:%.2f Status:%s",bmi,status);

       //開始準備回傳資料
        Intent newData = new Intent();
        newData.putExtra("bmi_msg",msg);//設定計算後的資料
        setResult(RESULT_OK,newData);//設定回傳的數值
        finish();//關閉目前Activity
    }
}
