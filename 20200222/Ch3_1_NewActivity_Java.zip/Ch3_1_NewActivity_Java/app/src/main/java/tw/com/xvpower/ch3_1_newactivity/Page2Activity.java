package tw.com.xvpower.ch3_1_newactivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Page2Activity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.page2_activity_layout);
       Button toPage3Btn = findViewById(R.id.toPage3Btn);
       TextView  shwoNameText =  findViewById(R.id.showNameText);
       Intent dataIntent =   getIntent();
        String name = dataIntent.getStringExtra("name");
        shwoNameText.setText(name);

        toPage3Btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toPage3Int = new Intent(Page2Activity.this,
                        Page3Activity.class);
                startActivity(toPage3Int);
            }
        });
    }
}
