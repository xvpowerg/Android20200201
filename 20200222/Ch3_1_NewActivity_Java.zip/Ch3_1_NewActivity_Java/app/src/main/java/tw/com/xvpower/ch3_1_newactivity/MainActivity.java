package tw.com.xvpower.ch3_1_newactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = findViewById(R.id.toPage2Btn);
       final EditText nameEdT =  findViewById(R.id.nameEDT);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //我的目標是:由 MainActivity  到 Page2Activity
                //我要提供: 目前是哪個Activity 我要 轉換的Activity是誰
                Intent toPage2Intent = new Intent(MainActivity.this,
                        Page2Activity.class);

                //加入要傳送到Page2的資料
                String nameStr = nameEdT.getText().toString();
                toPage2Intent.putExtra("name",nameStr);
                //開始切換到Page2Activity
                startActivity(toPage2Intent);
            }
        });

    }
}
