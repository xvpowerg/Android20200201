package tw.com.xvpower.mask_app.gson.data

import com.google.gson.annotations.SerializedName

data class Geometry(
                    @SerializedName("coordinates")
                    val coordinates:
                    ArrayList<Double>){
    //經度
    fun getLot():Double{
        return coordinates[0]
    }

    //緯度
    fun getLat():Double{
        return coordinates[1]
    }

}