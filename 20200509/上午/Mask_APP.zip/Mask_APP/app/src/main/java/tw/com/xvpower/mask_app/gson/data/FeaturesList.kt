package tw.com.xvpower.mask_app.gson.data

import com.google.gson.annotations.SerializedName

data class FeaturesList(
    @SerializedName("features")
    val features:ArrayList<Feature>)