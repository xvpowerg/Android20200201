package tw.com.xvpower.mask_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import okhttp3.*
import tw.com.xvpower.mask_app.tools.ParserMaskJson
import java.io.IOException
import java.util.concurrent.TimeUnit

class MainActivity : AppCompatActivity() {
   val url = "https://raw.githubusercontent.com/kiang/pharmacies/master/json/points.json"
  //okhttp3  https://square.github.io/okhttp/
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val json = TestJson.maskJson
        val client = OkHttpClient.Builder().run {
                    retryOnConnectionFailure(true)
                    readTimeout(10,TimeUnit.SECONDS)
                   build()
          }
    val request = Request.Builder().url(url).build()
      val callback = object :Callback{
          override fun onFailure(call: Call, e: IOException) {
              Log.d("Howard","onFailure:"+e)
          }

          override fun onResponse(call: Call, response: Response) {
              response.body?.run {
                  val josn = string()
                  val maskList = ParserMaskJson.parserToMaskListGson(josn)
                   //val maskList = ParserMaskJson.parserToMaskList(josn)
                  Log.d("Howard","Json:${maskList.size}")
              }
             Log.d("Howard","onResponse")
          }
      }
    client.newCall(request).enqueue(callback)

//      val list =   ParserMaskJson.parserToMaskList(json)
//        Log.d("Howard","list:${list}")
    }
}
