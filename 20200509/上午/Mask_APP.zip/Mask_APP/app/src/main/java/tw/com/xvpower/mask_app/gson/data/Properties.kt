package tw.com.xvpower.mask_app.gson.data
import com.google.gson.annotations.SerializedName
data class Properties(
                     @SerializedName("address")
                     val address:String,
                     @SerializedName("name")
                      val name:String,
                     @SerializedName("mask_adult")
                      val maskAdult:Int,
                     @SerializedName("mask_child")
                      val maskChild:Int)