package tw.com.xvpower.mask_app.tools

import android.Manifest
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class CheckGSPPermission {
    companion object{
        fun checkPermission(activity: AppCompatActivity,requestCode:Int,
                            grantedCallback:()->Unit){
                if (ContextCompat.
                    checkSelfPermission(activity,Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED){
                    grantedCallback()
                }else{
                        ActivityCompat.requestPermissions(activity,
                            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                            requestCode)
                }
        }
    }

}