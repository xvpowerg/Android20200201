package tw.com.xvpower.mask_app.tools

import android.location.Location

class LocationTools {
    companion object{
        fun distance(startLat:Double, startLgt:Double,
                     endLat:Double, endLgt: Double):Float{
            val result = FloatArray(1)
            //計算出的Float 單位為公尺
            //兩經緯度算出之間的距離
            Location.distanceBetween(startLat,startLgt,
                endLat,endLgt,result)
            //轉換為公里
            return result[0]/1000
        }

    }
}