package tw.com.xvpower.mask_app.adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView
import tw.com.xvpower.mask_app.R
import tw.com.xvpower.mask_app.data.MaskData

class MaskAdapter(private val maskDataList:List<MaskData>,
                  private val context: Context) : BaseAdapter() {
    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
       val view= LayoutInflater.from(context).inflate(R.layout.list_view_layout,
            parent,
            false)
        val maskData =   maskDataList[position]
        val name = maskData.name
        val adultCount = "成人口罩數量:${maskData.maskAdult}"
        val childCount = "兒童口罩數量:${maskData.maskChild}"
        val address = maskData.address
        view.findViewById<TextView>(R.id.nameText).run { text = name }
        view.findViewById<TextView>(R.id.adultCountText).run { text = adultCount }
        view.findViewById<TextView>(R.id.childCountText).run { text = childCount }
        view.findViewById<TextView>(R.id.addressText).run { text = address }
        return view
    }
    override fun getItem(position: Int): MaskData {
        return maskDataList[position]
    }
    override fun getItemId(position: Int): Long {
        return position.toLong()
    }
    override fun getCount(): Int {
        return maskDataList.size
    }
}