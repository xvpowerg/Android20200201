package tw.com.xvpower.mask_app.tools

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import org.json.JSONObject
import tw.com.xvpower.mask_app.data.MaskData
import tw.com.xvpower.mask_app.gson.data.FeaturesList

class ParserMaskJson {
        companion object{
            fun parserToMaskListGson(json:String):List<MaskData>{
                //給Gson一個轉換的類型
                val type = object : TypeToken<FeaturesList>() {}.type
                //把Json轉為相對應物件
               val fList =  Gson().fromJson<FeaturesList>(json,type)
                val maskDataList  =  fList.features.asSequence().map {
                    val p=it.properties
                    val g= it.geometry
                    val address = p.address
                    val name = p.name
                    val maskAdult = p.maskAdult
                    val maskChild = p.maskChild
                    val lot:Double = g.getLot()
                    val lat:Double = g.getLat()
                    MaskData(address,name,maskAdult,maskChild,lot,lat)
                }.toList()
                return maskDataList
            }
            //使用android 內建API
            fun parserToMaskList(json:String):List<MaskData>{
                val maskDataList = mutableListOf<MaskData>()
                val jsonObj = JSONObject(json)
                val jsonArray =  jsonObj.getJSONArray("features")
                for (i   in 0 until  jsonArray.length()){
                    val properties =
                        jsonArray.getJSONObject(i).getJSONObject("properties")
                    val geometry =
                        jsonArray.getJSONObject(i).getJSONObject("geometry")
                    val address = properties.getString("address")
                    val name = properties.getString("name")
                    val maskAdult = properties.getInt("mask_adult")
                    val maskChild = properties.getInt("mask_child")
                    val coordinates = geometry.getJSONArray("coordinates")
                    val lot = coordinates.getDouble(0)
                    val lat = coordinates.getDouble(1)
                    val maskData = MaskData(address,name,
                        maskAdult,maskChild,lot,lat)
                    maskDataList.add(maskData)
                }
                return maskDataList
            }

        }

}