package tw.com.xvpower.mask_app.listener

import android.location.Location
import android.location.LocationListener
import android.os.Bundle

class MyLocationListener(val changeCallBack:(location:Location)->Unit) : LocationListener {
    override fun onLocationChanged(location: Location) { changeCallBack(location) }
    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
    override fun onProviderEnabled(provider: String?) {}
    override fun onProviderDisabled(provider: String?) {}
}