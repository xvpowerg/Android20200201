package tw.com.xvpower.mask_app.gson.data

import com.google.gson.annotations.SerializedName

data class Feature(
    @SerializedName("properties")
    val properties: Properties,
    @SerializedName("geometry")
    val geometry: Geometry
)