package tw.com.xvpower.mask_app.data

data class MaskData(val address:String,
                    val name:String,
                    val maskAdult:Int,
                    val maskChild:Int,
                    val lot:Double,
                    val lat:Double)