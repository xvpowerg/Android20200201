package tw.com.xvpower.mask_app

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TimeUtils
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import tw.com.xvpower.mask_app.adapter.MaskAdapter
import tw.com.xvpower.mask_app.listener.MyLocationListener
import tw.com.xvpower.mask_app.tools.CheckGSPPermission
import tw.com.xvpower.mask_app.tools.FetchMaskJson
import tw.com.xvpower.mask_app.tools.LocationTools
import tw.com.xvpower.mask_app.tools.ParserMaskJson
import java.io.IOException
import java.util.concurrent.TimeUnit


class MainActivity : AppCompatActivity() {
    private val context: Context = this
    private var lastLocation: Location? = null
    private lateinit var locationManager: LocationManager
    private var myLocationListener: LocationListener? = null
    private fun fetchMaskJson() {
        val callback = object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                Log.d("Howard", "onFailure:" + e)
            }
            override fun onResponse(call: Call, response: Response) {
                response.body?.run {
                    val json = string()
                    //Gson Parser
                    var maskList = ParserMaskJson.parserToMaskListGson(json)
                    //如果lastLocation 是null就等一下
                    while(lastLocation == null){
                        TimeUnit.SECONDS.sleep(1)
                    }
                    maskList =  maskList.asSequence().sortedBy {
                         lastLocation?.run {
                                LocationTools.distance(
                                    latitude,
                                    longitude,
                                    it.lat,it.lot)
                            }
                        }.toList()

                    runOnUiThread() {
                        maskListView.adapter = MaskAdapter(maskList, context)
                        progressBar.visibility = View.INVISIBLE
                        //按下Item 可導航
                        maskListView.setOnItemClickListener { parent, view, position, id ->
                            val maskData = maskList[position]
                            lastLocation?.run {
                                val saddr = "saddr=${latitude},${longitude}"// 目前的位置
                                val daddr = "daddr=${maskData.lat},${maskData.lot}"//商店的位置
                                //saddr 開始 daddr 目標
                                val uriString = "http://maps.google.com/maps?$saddr&$daddr"
                                val uri = Uri.parse(uriString)
                                val intent = Intent(Intent.ACTION_VIEW, uri)
                                //指定使用Google Map開啟
                                intent.setClassName("com.google.android.apps.maps",
                                    "com.google.android.maps.MapsActivity");
                                startActivity(intent);
                            }
                        }
                    }
                }
            }
        }
        FetchMaskJson.fetch(callback)
    }

    @SuppressLint("MissingPermission")
    private fun addLocationListener() {
        locationManager.run {
            requestLocationUpdates(
                LocationManager.NETWORK_PROVIDER,
                2000L, 0f,
                myLocationListener
            )
            requestLocationUpdates(
                LocationManager.GPS_PROVIDER,
                2000L, 0f,
                myLocationListener
            )
        }
    }

    private fun initGPSManager() {
        if (myLocationListener == null) {
            locationManager =
                getSystemService(Context.LOCATION_SERVICE) as LocationManager
            myLocationListener = MyLocationListener() { lastLocation = it }
            CheckGSPPermission.checkPermission(
                this,
                100,
                this::addLocationListener
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    override fun onStart() {
        super.onStart()
        initGPSManager()
    }

    override fun onResume() {
        super.onResume()
        fetchMaskJson()
    }

    override fun onStop() {
        super.onStop()
        locationManager.removeUpdates(myLocationListener)
        myLocationListener = null
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        if (requestCode != 100) return
        if (grantResults.isNotEmpty() && grantResults[0] ==
            PackageManager.PERMISSION_GRANTED
        ) {
            addLocationListener()
        }
    }

}
