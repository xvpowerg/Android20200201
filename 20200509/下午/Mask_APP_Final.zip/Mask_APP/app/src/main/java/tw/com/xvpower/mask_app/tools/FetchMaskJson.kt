package tw.com.xvpower.mask_app.tools

import okhttp3.Callback
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit

class FetchMaskJson  {
    companion object{
        private val url =
            "https://raw.githubusercontent.com/kiang/pharmacies/master/json/points.json"
        fun fetch(callback: Callback){
            val client = OkHttpClient.Builder().run {
                retryOnConnectionFailure(true)
                readTimeout(10, TimeUnit.SECONDS)
                build()
            }
            val request = Request.Builder().url(url).build()
            client.newCall(request).enqueue(callback)
        }
    }
}