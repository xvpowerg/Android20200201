package tw.com.xvpower.ch7_checkbox_2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<CheckBox> checkList = new ArrayList<>();
       EditText numberText =  findViewById(R.id.boxCountText);
       Button submitBtn =   findViewById(R.id.submitBtn);
       CheckBox boxAll =  findViewById(R.id.checkAllBox);
       ViewGroup vg = findViewById(R.id.checkBoxGroup);

        boxAll.setOnClickListener(ev->{
            checkList.forEach(c->c.setChecked(boxAll.isChecked()));
        });

        submitBtn.setOnClickListener(ev->{
            vg.removeAllViews();
            checkList.clear();
            String countStr =
                    numberText.getText().toString();
            if (countStr.isEmpty()){
                Toast.makeText(this,
                        "錯誤的數量",Toast.LENGTH_SHORT).show();
                return;
            }
          int count =  Integer.parseInt(countStr);
            for (int i=1;i<=count;i++){
                CheckBox box = new CheckBox(this);
                checkList.add(box);
                box.setText("Box"+i);
                vg.addView(box);
            }
        });







    }
}
