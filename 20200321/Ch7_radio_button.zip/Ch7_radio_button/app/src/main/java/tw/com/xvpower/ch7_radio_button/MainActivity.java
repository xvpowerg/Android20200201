package tw.com.xvpower.ch7_radio_button;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private String msg = "未設定";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RadioButton rb1 =  findViewById(R.id.statusRB1);
        RadioButton rb2 =  findViewById(R.id.statusRB2);
        RadioButton rb3 =  findViewById(R.id.statusRB3);
        Button submitBtn =  findViewById(R.id.submitBtn);

        Map<Integer,RadioButton> cache = new HashMap<>();
        cache.put(R.id.statusRB1,rb1);
        cache.put(R.id.statusRB2,rb2);
        cache.put(R.id.statusRB3,rb3);
      RadioGroup rg1 =  findViewById(R.id.radioGroup1);
        rb1.setOnClickListener(e->{
           Log.d("Howard","Radio:"+rb1.isChecked()+"text:"+rb1.getText());
        });
        rg1.setOnCheckedChangeListener((bv,isChecked)->{
            //isChecked 是一個被選取的RadioButton 的 id

//              RadioButton tb =   findViewById(isChecked);
//            Log.d("Howard", "isChecked:"+
//                    tb.getText());
            RadioButton tb2 =   cache.get(isChecked);
            msg = tb2.getText().toString();
            Log.d("Howard", "isChecked:"+
                    tb2.getText());
        });

        submitBtn.setOnClickListener(ev->{

            Toast.makeText(this,msg,Toast.LENGTH_SHORT).show();

        });
    }
}
