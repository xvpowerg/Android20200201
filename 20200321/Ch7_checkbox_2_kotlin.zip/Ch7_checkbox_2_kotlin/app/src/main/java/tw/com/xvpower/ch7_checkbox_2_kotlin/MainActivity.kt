package tw.com.xvpower.ch7_checkbox_2_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val list = mutableListOf<CheckBox>()
        checkAllBox.setOnClickListener {allBox->
            if (allBox is CheckBox){
                list.forEach {
                    it.isChecked = allBox.isChecked
                }
            }
        }

        submitBtn.setOnClickListener {
            checkBoxGroup.removeAllViews()
            list.clear()
            val contStr = boxCountText.text.toString()
            if (contStr.isEmpty()){
                Toast.makeText(this,"錯誤",Toast.LENGTH_SHORT).show()
            }
            val count = contStr.toInt()
            for (n in 1..count){
                val checkBox = CheckBox(this)
                checkBox.text = "Box$n"
                list.add(checkBox)
                checkBoxGroup.addView(checkBox)
            }

        }
    }
}
