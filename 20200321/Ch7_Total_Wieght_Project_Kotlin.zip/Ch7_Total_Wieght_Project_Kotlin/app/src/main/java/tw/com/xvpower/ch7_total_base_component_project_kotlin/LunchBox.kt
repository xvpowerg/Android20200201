package tw.com.xvpower.ch7_total_base_component_project_kotlin

import android.os.Parcel
import android.os.Parcelable

data class LunchBox(val name:String?,val price:Int,val count:Int) :Parcelable{
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readInt(),
        parcel.readInt()
    )
    override fun writeToParcel(dest: Parcel?, flags: Int) {
        dest?.writeString(name)
        dest?.writeInt(price)
        dest?.writeInt(count)
    }
    override fun describeContents(): Int {
        return 0
    }
    fun total():Int = price * count
    companion object CREATOR : Parcelable.Creator<LunchBox> {
        override fun createFromParcel(parcel: Parcel): LunchBox {
            return LunchBox(parcel)
        }
        override fun newArray(size: Int): Array<LunchBox?> {
            return arrayOfNulls(size)
        }
    }
}

