package tw.com.xvpower.ch7_total_base_component_project_kotlin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*
import java.lang.StringBuilder

class MainActivity : AppCompatActivity() {


        private fun settingListener(itemEditMap:Map<Int,EditText>,
                                    checkBoxArray:Array<CheckBox>){
            val onChangeListener:(CompoundButton, Boolean)->Unit={
                    buttonView, isChecked ->
                itemEditMap[buttonView.id]?.apply {
                    isEnabled = isChecked
//              isClickable = isChecked
//              isFocusable = isChecked
//              isFocusableInTouchMode = isChecked
                }
            }
            checkBoxArray.forEach {
                it.setOnCheckedChangeListener(onChangeListener)
            }
        }

    private fun submitBtnInitForObject(checkBoxArray:Array<CheckBox>,
                              itemEditMap:Map<Int,EditText>,
                              itemPriceMap:Map<Int,Int>){
        submitBtn.setOnClickListener {
          val list =  checkBoxArray.asSequence().filter {
                it.isChecked
          }.map {
              val (name,_)  =  it.text.toString().split(" ")
               val price= itemPriceMap[it.id]?:0
                val countSt = itemEditMap[it.id]?.text.toString()
                   countSt.toInt()
                LunchBox(name,price, countSt.toInt())
            }.toCollection(mutableListOf())

            val intent = Intent(this,Page2Activity::class.java)
            val arrayList = list as ArrayList
            intent.putParcelableArrayListExtra("list",arrayList)
            startActivity(intent)
        }
    }
        private fun submitBtnInit(checkBoxArray:Array<CheckBox>,
                               itemEditMap:Map<Int,EditText>,
                               itemPriceMap:Map<Int,Int>){
            submitBtn.setOnClickListener {
                val sb = StringBuilder()
                checkBoxArray.forEach {
                    if (it.isChecked){
                        sb.append(it.text)
                        val countStr = itemEditMap[it.id]?.text.toString()
                        val str:String? =
                            itemPriceMap[it.id]?.let {p->
                                "${countStr.toInt() * p}"
                            }
                        sb.append(",$countStr,$str")
                        sb.append("\n")
                    }
                }
                val toPage2Intent = Intent(this,
                    Page2Activity::class.java)
                toPage2Intent.putExtra("msg",sb.toString())
                startActivity(toPage2Intent)
                Log.d("Howard","msg:${sb.toString()}");
            }
        }
        inner  class InitData{
            operator fun component1():Array<CheckBox>
                  = arrayOf(checkBoxItem1,
                    checkBoxItem2,
                    checkBoxItem3)
            operator fun component2():Map<Int,EditText>
                = mapOf<Int,EditText>(
                    R.id.checkBoxItem1 to Item1editText,
                    R.id.checkBoxItem2 to Item2editText,
                    R.id.checkBoxItem3 to Item3editText)
            operator fun component3():Map<Int,Int> = mapOf<Int,Int>(
                R.id.checkBoxItem1 to 80,
                R.id.checkBoxItem2 to 75,
                R.id.checkBoxItem3 to 60)
        }

        private fun init(){
            val(checkBoxArray,itemEditMap,itemPriceMap) =InitData()
            settingListener(itemEditMap,checkBoxArray)
           // submitBtnInit(checkBoxArray,itemEditMap,itemPriceMap);//使用字串處理
            submitBtnInitForObject(checkBoxArray,itemEditMap,itemPriceMap)
        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        init()
    }
}
