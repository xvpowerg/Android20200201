package tw.com.xvpower.ch7_total_base_component_project_kotlin

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.page2_layout.*

class Page2Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.page2_layout)
        val list=
            intent.getParcelableArrayListExtra<LunchBox>("list")
        Log.d("Howard","$list")
//        val info = intent.getStringExtra("msg")
//        info?.let {
//            orderInfoTxt.text = it
//        }

    }
}