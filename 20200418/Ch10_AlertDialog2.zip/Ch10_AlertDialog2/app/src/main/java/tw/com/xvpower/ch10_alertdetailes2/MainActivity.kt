package tw.com.xvpower.ch10_alertdetailes2

import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.icu.util.TimeUnit
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.TimeUtils
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import java.io.InputStream
import java.net.URL

class MainActivity : AppCompatActivity() {

    private fun  singleDialogFun(view:View){
        val array = arrayOf("穩定","單身","一言難盡")
        var option = ""
        AlertDialog.Builder(this).setTitle("感情狀態").
        setPositiveButton("確定"){_,_ ->
            Toast.makeText(this,option,Toast.LENGTH_SHORT).show() }.
        setSingleChoiceItems(array,0){
            _,w->option = array[w]
        }.show()
    }

    private  fun multipleDialogBtn(view:View){
        val array = arrayOf("電影","音樂","閱讀","運動","電動");
       // val boolArray =   booleanArrayOf(true,false,false,true,false)//有預設勾選
        val boolArray = BooleanArray(array.size)
        AlertDialog.Builder(this).setTitle("Titile").
        setPositiveButton("確定"){_,_->
          val msg =  boolArray.asSequence().filter { b->b }.
          mapIndexed { index,_ -> array[index] }.
            joinToString()
            Log.d("Howard","msg:$msg")
        Toast.makeText(this,msg,Toast.LENGTH_SHORT).show()
        }.
        setMultiChoiceItems(array,boolArray){
            _,w,c->
            Log.d("Howard","multiple:${array[w]}:$c")
        }.show()
    }
    private fun progressDialog(view:View){
         val view =  layoutInflater.inflate(R.layout.progress_layout,null)
        val progressBar = view.findViewById<ProgressBar>(R.id.progressBar)
          val dialog =  AlertDialog.Builder(this).setCancelable(false).setTitle("下載中!").
           setView(view).show()
        val url =
            "https://media.kasperskydaily.com/wp-content/uploads/sites/92/2019/12/09084248/android-device-identifiers-featured.jpg"
        LoadImage(url){
            //runOnUiThread 的大誇號內 可以切換到original thread也就是UI Thread
            runOnUiThread {
                //運行在 original thread
                imageView.setImageBitmap(it)
                progressBar.visibility = View.INVISIBLE
                dialog.dismiss()
            }
        }.start()

//        val th1 = Thread(){
//            Thread.sleep(2000)//模擬要做2秒
//            progressBar.visibility = View.INVISIBLE
//            dialog.dismiss()//關閉dialog
//        }
//        th1.start()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        singleDialogBtn.setOnClickListener(this::singleDialogFun)
        multipleDialogBtn.setOnClickListener(this::multipleDialogBtn)
        progressDialogBtn.setOnClickListener(this::progressDialog)
    }
}
//android View只是使用original thread 去控制
class LoadImage(private val url:String,
                private val callback:(bitmap:Bitmap)->Unit ):Thread(){
        override fun run(){
           val bmp = ImageUtils.getImage(url)
            Log.d("Howard","BitMap:$bmp")
            callback(bmp)

        }
}

class ImageUtils {
    // companion object 可讓方法變靜態
    companion object{
        private fun fetch(urlLink:String):Any{
              val url = URL(urlLink)
            return url.content
        }
        //下載圖片檔
        fun getImage(url:String):Bitmap{
            val ins = fetch(url) as InputStream
           val bitmapDrawable =
               Drawable.createFromStream(ins,"src") as BitmapDrawable
            return bitmapDrawable.bitmap
        }
    }

}
