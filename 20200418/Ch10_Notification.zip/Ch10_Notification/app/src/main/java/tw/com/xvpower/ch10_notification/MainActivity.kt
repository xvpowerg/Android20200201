package tw.com.xvpower.ch10_notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private var progressNumber:Int =0
    private val CHANNEL_ID="msge1"
    private fun createNotificationChannel(){
         if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ){
            val name = "C1"
             val desName = "DesName"
             val imp=  NotificationManager.IMPORTANCE_DEFAULT
             val channel = NotificationChannel(CHANNEL_ID,name,imp).
                        apply {
                        description = desName
                    }
            val notifiManager =  getSystemService(Context.NOTIFICATION_SERVICE) as
                                    NotificationManager
             notifiManager.createNotificationChannel(channel)

         }
    }


    private fun testNotify1(view: View){
        //設定Notification 內容
        //setSmallIcon  一定要設定 圖片一定要灰階
       val builder = NotificationCompat.Builder(this,CHANNEL_ID).
            setSmallIcon(R.drawable.notifiy_img).
            setContentTitle("Title").setContentText("ContentText Test!!  Test!! Test!! Test!! Test!!" +
                    " Test!! Test!! Test!! Test!! Test!! Test!!")
         val notify = builder.build()
        createNotificationChannel()
        //傳送notify
        NotificationManagerCompat.from(this).
        notify(1,notify)
    }
    private fun testNotify2(view: View){
        val ID = 2
        val builder = NotificationCompat.Builder(this,CHANNEL_ID).apply {
            setSmallIcon(R.drawable.notifiy_img)
            setContentTitle("Title Big Text!!")
            setContentText("ContentText!")
            setStyle(NotificationCompat.BigTextStyle().bigText("BIg Text! BIg Text! BIg Text! BIg " +
                    "Text! BIg Text! BIg Text! " +
                    "BIg Text! BIg Text! BIg Text! BIg Text! " +
                    "BIg Text! BIg Text! BIg Text! BIg Text!"))
            priority = NotificationCompat.PRIORITY_HIGH
        }

        NotificationManagerCompat.from(this).run {
            notify(ID,builder.build())
        }
    }
    private fun testNotify3(view: View){
        val ID = 3
        //希望在此設定Msg訊息後 送到下一個Activity
        val intent = Intent(this,NotifiActivity::class.java)
        intent.putExtra("msg","Values!!");
        //等一下才會做某件事 可使用PendingIntent
      val  pendingIntent = PendingIntent.
                        getActivity(this,0,
                            intent,PendingIntent.FLAG_UPDATE_CURRENT)
       val builder =  NotificationCompat.Builder(this,CHANNEL_ID).apply {
        setSmallIcon(R.drawable.notifi_activity)
            setContentTitle("開啟訊息")
          priority = NotificationCompat.PRIORITY_MAX
            setContentIntent(pendingIntent)//設定按下Notifiy時要轉換的Activity
            setAutoCancel(true)//當按下了Notify後可自動關閉目前Notify
      }
        createNotificationChannel()
        NotificationManagerCompat.from(this).
        notify(ID,builder.build())
    }


    private fun testNotification4(view:View){
        val ID=4
        val builder = NotificationCompat.Builder(this,CHANNEL_ID).
            apply {
            setContentTitle("Download..")
           setContentText("Download in progress..")
            setSmallIcon(R.drawable.notifiy_img)
            priority = NotificationCompat.PRIORITY_LOW
        }
        val max = 100
        progressNumber += 10
        builder.setProgress(max,progressNumber,false)
        val notify = builder.build()
        NotificationManagerCompat.from(this).notify(ID,notify)

    }

    private fun testNotification5(view:View){
        val ID=5
        val builder = NotificationCompat.Builder(this,CHANNEL_ID).
        apply {
            setContentTitle("Download..")
            setContentText("Download in progress..")
            setSmallIcon(R.drawable.notifi_activity)
            priority = NotificationCompat.PRIORITY_LOW
        }
        val max = 100
        NotificationManagerCompat.from(this).apply {
                Thread{
                    val range = 0 .. max
                      for (current in range step  10){
                          builder.setProgress(max,current,false)
                          notify(ID,builder.build())
                          Thread.sleep(1000)
                      }
                    builder.setContentText("Download Complete!").
                    setProgress(0,0,false)
                    notify(ID,builder.build())
                }.start()
        }

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        createNotificationChannel()
        nofiBtn1.setOnClickListener(this::testNotify1)
        notifiBtn2.setOnClickListener(this::testNotify2)
        notifiopenActivityBtn.setOnClickListener(this::testNotify3)
        progtressBtn.setOnClickListener(this::testNotification4)
        progtressBtnThread.setOnClickListener(this::testNotification5)

    }
}
