package tw.com.xvpower.ch5_2_transitionanimation

import android.app.ActivityOptions
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*
import android.util.Pair
class MainActivity : AppCompatActivity() {

    private fun showDetail(myView:View){
        val myIntent = Intent(this,
            DetailActivity::class.java)
        myIntent.putExtra("viewId",myView.id)
        val titleView = titleimageView as View
        val p1 = Pair(titleView,"tarn1")
        val p2 = Pair(myView,"tarn2")
        val option =  ActivityOptions.makeSceneTransitionAnimation(this,p1,p2)
        startActivity(myIntent,option.toBundle())
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        user1Btn.setOnClickListener{showDetail(it)}
        user2Btn.setOnClickListener{showDetail(it)}
        user3Btn.setOnClickListener {showDetail(it)}
        user4Btn.setOnClickListener{showDetail(it) }
    }
}
