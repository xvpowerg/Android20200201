package tw.com.xvpower.ch5_2_transitionanimation

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.transition.Explode
import android.transition.Fade
import android.transition.Slide
import android.view.Window
import kotlinx.android.synthetic.main.activity_detail.*
import tw.com.xvpower.ch5_2_transitionanimation.consts.IMAGE_MAP
import tw.com.xvpower.ch5_2_transitionanimation.consts.USER_INFO_MAP

class DetailActivity : AppCompatActivity() {
    private fun setupTransition(viewId:Int){
        window.requestFeature(Window.FEATURE_CONTENT_TRANSITIONS)
       when(viewId){
           R.id.user2Btn->{
               val explode =  Explode()
               explode.duration = 1000
               window.enterTransition = explode
               window.exitTransition = explode
           }
         R.id.user3Btn->{
             val slide =  Slide()
             slide.duration = 1000
             window.enterTransition = slide
             window.exitTransition = slide

         }
         R.id.user4Btn->{
             val fade = Fade()
             fade.duration = 2000
             window.enterTransition =fade
             window.exitTransition =fade
         }

       }



    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val viewID =  intent.getIntExtra("viewId",0)
        //一定要在setContentView 之前呼叫
        setupTransition(viewID)
        setContentView(R.layout.activity_detail)
        IMAGE_MAP[viewID]?.let {
            userImage.setImageResource(it)
        }
        USER_INFO_MAP[viewID]?.let {
         val infoArray=   resources.
         getStringArray(R.array.user_info)
            showUserTxt.text =infoArray[it]
        }



    }

}
