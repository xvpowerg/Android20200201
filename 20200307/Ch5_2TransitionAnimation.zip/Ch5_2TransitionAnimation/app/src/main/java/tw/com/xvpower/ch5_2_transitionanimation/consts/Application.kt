package tw.com.xvpower.ch5_2_transitionanimation.consts

import kotlinx.android.synthetic.main.activity_main.view.*
import tw.com.xvpower.ch5_2_transitionanimation.R

val IMAGE_MAP = mapOf(Pair<Int,Int>(R.id.user1Btn,
    R.drawable.image1),
    Pair<Int,Int>(R.id.user2Btn,R.drawable.image2),
    Pair<Int,Int>(R.id.user3Btn,R.drawable.image3),
    Pair<Int,Int>(R.id.user4Btn,R.drawable.image4))
val USER_INFO_MAP = mapOf(Pair<Int,Int>(R.id.user1Btn,0),
    Pair<Int,Int>(R.id.user2Btn,1),
    Pair<Int,Int>(R.id.user3Btn,2),
    Pair<Int,Int>(R.id.user4Btn,3)
 )