package com.example.ch5_share_data_java;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import tw.com.xvpower.ch5_share_data_java.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button shareBtn1 = findViewById(R.id.shareBtn1);
        Button shareBtn2 = findViewById(R.id.shareBtn2);

        shareBtn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //分享文字
                Intent myIntent = new Intent();
                myIntent.setAction(Intent.ACTION_SEND);
                //分享文字內容
                myIntent.putExtra(Intent.EXTRA_TEXT,"Share Value!!");
                //分享的類型
                myIntent.setType("text/plain");
                startActivity(Intent.createChooser(myIntent,"選擇傳送App"));

            }
        });

        shareBtn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent myIntent = new Intent();
                myIntent.setAction(Intent.ACTION_SEND);
                Uri uri = Uri.parse("android:resource://"+
                        MainActivity.this.getPackageName()+"/"+
                        R.drawable.test1);
                myIntent.putExtra(Intent.EXTRA_STREAM,uri);
                myIntent.setType("image/jpg");
                startActivity(Intent.createChooser(myIntent,"選擇分享對象"));
            }
        });
    }
}
