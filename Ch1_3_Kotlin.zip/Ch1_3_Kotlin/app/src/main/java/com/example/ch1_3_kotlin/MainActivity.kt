package com.example.ch1_3_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

fun EditText.toTextString():String = this.text.toString()
class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        showToastBtn.setOnClickListener {
           val n1Str =  number1Edit.text.toString()
            val ans = if (n1Str.isNotEmpty())
                        number1Edit.text.toString().toInt() + 20
                     else 0
          Toast.makeText(this,"Msg!$ans",
                Toast.LENGTH_LONG).show()
        }
//加了toTextString 之後
//
//        val n1Str =  number1Edit.toTextString()
//        val ans = if (n1Str.isNotEmpty())
//            n1Str.toInt() + 20
//        else 0
//        Toast.makeText(this,"Msg!$ans",
//            Toast.LENGTH_LONG).show()
    }
}
