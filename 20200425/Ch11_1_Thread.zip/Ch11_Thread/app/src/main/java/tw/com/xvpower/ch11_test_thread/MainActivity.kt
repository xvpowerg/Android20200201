package tw.com.xvpower.ch11_test_thread

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
        private lateinit var handler: Handler
    fun startBtn1(view: View){
        val th1 =  Thread(){
            for ( i in 10 downTo 1  ){
                numberTxt.text = "$i"
                Thread.sleep(1000)
            }
            runOnUiThread {
                imageView.
                setImageResource(R.drawable.image1)
            }

        }
        th1.start()
    }

    private fun startBtn2(view: View){
       val countdown = Countdown()
        countdown.start({count->
            numberTxt.text = "$count"
        },handler){
            imageView.setImageResource(R.drawable.image1)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        handler = Handler()
        startBtn.setOnClickListener(this::startBtn1)
        start2Btn.setOnClickListener(this::startBtn2)

    }
}
