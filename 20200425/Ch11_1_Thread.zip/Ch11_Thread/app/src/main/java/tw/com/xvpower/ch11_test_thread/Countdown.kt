package tw.com.xvpower.ch11_test_thread

import android.os.Handler
import java.util.concurrent.TimeUnit


class Countdown {
    fun start(msg:(count:Int)->Unit,handler: Handler?=null,callBack:()->Unit){
        val thread = Thread(){
            for (i in  5 downTo 1 ){
                msg(i)
                TimeUnit.SECONDS.sleep(1)
            }
            if (handler == null){
                callBack()
            }else{
                handler.post {
                    //使用UI Thread
                    callBack()
                }
            }
        }
        thread.start()
    }
}