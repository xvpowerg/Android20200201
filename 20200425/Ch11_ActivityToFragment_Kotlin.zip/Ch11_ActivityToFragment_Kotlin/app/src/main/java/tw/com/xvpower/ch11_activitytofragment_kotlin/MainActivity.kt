package tw.com.xvpower.ch11_activitytofragment_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
     private val fp1 :FragmentPage1 = FragmentPage1()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportFragmentManager.beginTransaction().run {
            replace(R.id.fmContainer,fp1)
            commit()
        }
        submitBtn.setOnClickListener {
            var ans = ""
            ans += if (checkBox1.isChecked) "${checkBox1.text} " else ""
            ans += if (checkBox2.isChecked) "${checkBox2.text} "  else ""
            ans += if (checkBox3.isChecked) "${checkBox3.text} "  else ""
            fp1.setAnsText(ans)
        }
    }
}
