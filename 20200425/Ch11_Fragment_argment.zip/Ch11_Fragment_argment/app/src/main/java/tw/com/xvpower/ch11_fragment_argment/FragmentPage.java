package tw.com.xvpower.ch11_fragment_argment;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentPage extends Fragment {
    private PassAnsToMainLayout passAnsToMainLayout;
    public FragmentPage(){

    }

    public FragmentPage(PassAnsToMainLayout passAnsToMainLayout){
        this.passAnsToMainLayout = passAnsToMainLayout;
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_layout,container,false);
    }

    @Override
    public void onStart() {
        super.onStart();
       View layout =  getView();
      Button btn1 =   layout.findViewById(R.id.caluBtn1);
       Button btn2 = layout.findViewById(R.id.caluBtn2);

       EditText n1 =  layout.findViewById(R.id.n1Txt);
       EditText n2 =layout.findViewById(R.id.n2Txt);

      EditText n3 =  layout.findViewById(R.id.n3Txt);
      EditText n4 =  layout.findViewById(R.id.n4Txt);


        btn1.setOnClickListener(view->{
          int n1Value = Integer.parseInt(n1.getText().toString());
          int n2Value = Integer.parseInt(n2.getText().toString()) ;
          int ans = n1Value + n2Value;
            Log.d("Howard","ans:"+ans);
            passAnsToMainLayout.passAnsToLayout(ans);
        });

        btn2.setOnClickListener(view->{
         int n3Value =  Integer.
                 parseInt(n3.getText().toString());
         int n4Value =  Integer.
                 parseInt(n4.getText().toString());
         int ans = n3Value - n4Value;
            Log.d("Howard","ans:"+ans);
            passAnsToMainLayout.passAnsToLayout(ans);
        });
    }

}
