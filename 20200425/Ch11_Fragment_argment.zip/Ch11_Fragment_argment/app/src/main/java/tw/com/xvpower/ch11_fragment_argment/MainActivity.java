package tw.com.xvpower.ch11_fragment_argment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.os.Bundle;
import android.widget.TextView;

interface PassAnsToMainLayout{
    void passAnsToLayout(int value);
}

public class MainActivity extends AppCompatActivity {
    private FragmentPage fp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
      TextView ansView =  findViewById(R.id.ansView);
        fp = new FragmentPage(ans->{
            ansView.setText(ans+"");
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        getSupportFragmentManager().
                beginTransaction().
                replace(R.id.frmContainer,fp).
                commit();
    }
}
