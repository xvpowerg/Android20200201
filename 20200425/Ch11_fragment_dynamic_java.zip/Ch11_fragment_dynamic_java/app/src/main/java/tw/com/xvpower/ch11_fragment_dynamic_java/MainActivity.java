package tw.com.xvpower.ch11_fragment_dynamic_java;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private FrgamentPage1 page1 = new FrgamentPage1();
    private FragmentPage2 page2  = new FragmentPage2();
    private FragmentPage3 page3 = new FragmentPage3();
    private FragmentManager fm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        fm  =  getSupportFragmentManager();
       Button btn1 =   findViewById(R.id.page1Btn);
       Button btn2 = findViewById(R.id.page2Btn);
       Button btn3 = findViewById(R.id.page3Btn);
       btn1.setOnClickListener(view->{
           fm.beginTransaction().remove(page2).
                   add(R.id.frmContainer,page1).
                   addToBackStack("stack").commit();
       });
        btn2.setOnClickListener(view->{
            fm.beginTransaction().remove(page1).
                    add(R.id.frmContainer,page2).
                    addToBackStack("stack").commit();
           // fm.beginTransaction().add(R.id.frmContainer,page2).commit();
        });
        btn3.setOnClickListener(view->{
            //如果page3 存在就移除 再放入
        fm.beginTransaction().replace(R.id.frmContainer,page3).
                addToBackStack("stack").commit();
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        fm.beginTransaction().add(R.id.frmContainer,page1).commit();
    }

}
