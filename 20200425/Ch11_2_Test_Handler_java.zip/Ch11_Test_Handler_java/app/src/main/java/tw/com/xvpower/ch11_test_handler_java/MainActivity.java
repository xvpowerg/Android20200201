package tw.com.xvpower.ch11_test_handler_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Handler handler;
    private int count = 0;
    private Runnable run = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button startBtn =  findViewById(R.id.startBtn);
       TextView numberTxt =  findViewById(R.id.numberText);
        handler = new Handler();
        run = ()->{
            numberTxt.setText(++count+"");
            if (count < 10){
                Log.d("Howard","Thread name:"+Thread.currentThread().getName());
                handler.postDelayed(run,1000);//延遲1秒後 執行run物件
            }else{
                startBtn.setEnabled(true);
            }
        };
        startBtn.setOnClickListener(view->{
            Log.d("Howard","startBtn!!!");
            count = 0;
            handler.post(run);
            startBtn.setEnabled(false);
        });
    }
}
