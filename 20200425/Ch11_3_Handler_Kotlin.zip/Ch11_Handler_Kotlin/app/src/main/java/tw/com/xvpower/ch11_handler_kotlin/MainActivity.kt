package tw.com.xvpower.ch11_handler_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.view.View
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
      private lateinit var downloadImage:DownloadImage
    private lateinit var handler: Handler
    companion object{
        val IMAGE1:Int = 1
        val IMAGE2:Int = 2
        val IMAGE3:Int = 3
    }

    private  fun btnClick(view:View){
        var imageId = IMAGE1
        when(view.id){
            R.id.btn1->{imageId = IMAGE1 }
            R.id.btn2->{imageId = IMAGE2 }
            R.id.btn3->{imageId = IMAGE3}
        }
        downloadImage.startDownload(imageId,handler,{
            progressBar.visibility = View.VISIBLE
        },{
            progressBar.visibility = View.INVISIBLE
        })
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        downloadImage = DownloadImage()
        //Kotlin 匿名內類別寫法
        handler = object : Handler() {
            override fun handleMessage(msg: Message) {
                super.handleMessage(msg)
                val imageId = msg.data.getInt("imageId",-1)
                when(imageId){
                    IMAGE1->{ imageView.setImageResource(R.drawable.image1)  }
                    IMAGE2->{imageView.setImageResource(R.drawable.image2)   }
                    IMAGE3->{imageView.setImageResource(R.drawable.image3)  }
                }
            }
        }
        btn1.setOnClickListener(this::btnClick)
        btn2.setOnClickListener(this::btnClick)
        btn3.setOnClickListener(this::btnClick)
    }
}
