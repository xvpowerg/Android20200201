package tw.com.xvpower.ch11_handler_kotlin

import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message
import java.util.concurrent.TimeUnit

class DownloadImage {
     private fun runThread(id:Int,handler: Handler,
                   startDownUI:()->Unit,finishUI:()->Unit){
         //開始後的UI變動
         handler.post { startDownUI() }
         for (i in 1..5){
             TimeUnit.SECONDS.sleep(1)
         }
         //當圖片下載完之後 使用handler sendMessage去更新ImageView
         val msg = Message()
         val bundle = Bundle()
         bundle.putInt("imageId",id)
         msg.data = bundle
         handler.sendMessage(msg)

         //結束後的UI變動
         handler.post { finishUI() }
     }

     fun startDownload(id:Int,handler: Handler,
                       startDownUI:()->Unit,finishUI:()->Unit){
            val th1 = Thread(){
                runThread(id,handler,startDownUI,finishUI)
           }
         th1.start()
     }

}