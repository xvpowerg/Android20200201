package tw.com.xvpower.ch4_1_intent_implied;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button btn =  findViewById(R.id.toPageBtn);
       Button btn2= findViewById(R.id.button2);
        btn.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                //明確型呼叫Intent
                Intent int1 = new Intent(
                        MainActivity.this,
                                    Main2Activity.class);
                startActivity(int1);
            }
        });
        //隱含呼叫
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent toPage3 = new Intent("tw.com.xvpower.Activity3");
                startActivity(toPage3);
            }
        });

    }
}
