package tw.com.xvpower.ch4_1_intent_implied;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Main3Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        TextView msgText = findViewById(R.id.activity3Txt);
        Intent intent =  getIntent();
        String msg =  intent.getStringExtra("msg");
        Log.d("Howard","msg:"+msg);
        if (msg != null){
            msgText.setText(msg);
        }
    }
}
