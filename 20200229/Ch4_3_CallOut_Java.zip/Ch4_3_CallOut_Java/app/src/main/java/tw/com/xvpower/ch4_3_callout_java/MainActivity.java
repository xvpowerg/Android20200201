package tw.com.xvpower.ch4_3_callout_java;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final int CALL_OUT_REQUEST_CODE = 100;
    private String phoneNumber = "";
    private void checkPermissions(){
        //假設無 彈出讓使用者確認 權限的視窗
        //先確定是否已授權
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CALL_PHONE) ==
                PackageManager.PERMISSION_GRANTED){
            //Call Out
            Log.d("Howard","Call Out");
            callOut(phoneNumber);
        }else{
            //假設無授權 彈出讓使用者確認 權限的視窗
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CALL_PHONE},
                    CALL_OUT_REQUEST_CODE);
            Log.d("Howard","Check Permissions!!");
        }
    }


        @SuppressLint("MissingPermission")
        private void callOut(String phoneNumber)
        {
            Uri phoneUri = Uri.parse("tel:" + phoneNumber);
            Intent callOutIntent = new Intent(
                    Intent.ACTION_CALL, phoneUri);
            startActivity(callOutIntent);
        }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button callOutBtn = findViewById(R.id.callOutBtn);
        final EditText phoneNumberEt = findViewById(R.id.phoneNumberET);
        callOutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                 phoneNumber =
                        phoneNumberEt.getText().toString();
                checkPermissions();

            }
        });
    }

        //當使用者拒絕或允許授權時會呼叫
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == CALL_OUT_REQUEST_CODE) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d("Howard","GRANTED");
                callOut(phoneNumber);
            }else{
                Log.d("Howard","DENIED");
            }
        }
    }
}
