package tw.com.xvpower.ch4_1_intent_call_page3_kotilin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        toPage3Btn.setOnClickListener {
            val toPage3 = Intent("tw.com.xvpower.Activity3")
            toPage3.putExtra("msg","From Kotlin!")
            startActivity(toPage3)
        }
    }
}
