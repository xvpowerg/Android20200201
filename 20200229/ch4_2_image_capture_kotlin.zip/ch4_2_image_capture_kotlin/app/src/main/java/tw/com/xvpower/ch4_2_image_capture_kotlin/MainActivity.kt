package tw.com.xvpower.ch4_2_image_capture_kotlin

import android.content.Intent
import android.graphics.Bitmap
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
const val  CAPTRUE_IMAGE_RESULT_CODE = 1500
class MainActivity : AppCompatActivity() {
    //Bitmap? 表示bitmap 變數可以是null
    var bitmap :Bitmap? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        captureBtn.setOnClickListener {
            val toCaptrueImage = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivityForResult(toCaptrueImage,CAPTRUE_IMAGE_RESULT_CODE)
        }

        Log.d("Howard","onCreate !!..:$savedInstanceState")
    }


    override fun onStart() {
        super.onStart()
        Log.d("Howard","onStart !!..")
    }

    //取得由onSaveInstanceState 儲存的資料
    override fun onRestoreInstanceState(state: Bundle) {
        super.onRestoreInstanceState(state)
        Log.d("Howard","onRestoreInstanceState:$state")
        bitmap =   state.getParcelable<Bitmap>("myBitmap")
        imageView.setImageBitmap(bitmap)
    }
    override fun onResume() {
        super.onResume()
        Log.d("Howard","onResume !!..")
    }

    override fun onPause() {
        super.onPause()
        Log.d("Howard","onPause !!..")
    }

    override fun onStop() {
        super.onStop()
        Log.d("Howard","onStop !!..")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("Howard","onDestroy !!..")
    }
//作用在於 目前的Activity 可能被系統清除時呼叫
//按下Home 或是 App選擇鍵都會呼叫
  //將可能遺失的資料存到記憶體
    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
    Log.d("Howard","onSaveInstanceState $bitmap")
    outState.putString("howard","saveInstanceState")

    //Parcelable 輕巧版序列化
        bitmap?.let {
            outState.putParcelable("myBitmap",it)
        }
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when(requestCode){
            CAPTRUE_IMAGE_RESULT_CODE->{
                data?.extras?.run {
                    bitmap =  get("data") as Bitmap
                    imageView.setImageBitmap(bitmap)
                }

            }
        }
    }
}
