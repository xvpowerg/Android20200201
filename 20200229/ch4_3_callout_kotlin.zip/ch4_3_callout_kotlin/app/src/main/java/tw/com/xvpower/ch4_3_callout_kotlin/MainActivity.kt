package tw.com.xvpower.ch4_3_callout_kotlin

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*
const val CALL_OUT_REQUEST_CODE = 200
class MainActivity : AppCompatActivity() {

        @SuppressLint("MissingPermission")
        private fun callOut(){
            val phoneNumber = phoneNumberET.text.toString()
            val uri =Uri.parse("tel:$phoneNumber")
            val intent = Intent(Intent.ACTION_CALL,uri)
            startActivity(intent)
        }

        private fun checkPermissions():Boolean{
            return if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.CALL_PHONE) ==
                     PackageManager.PERMISSION_GRANTED){
                    Log.d("Howard","PERMISSION_GRANTED")
                      true
                }else{

                 ActivityCompat.requestPermissions(this,
                            arrayOf(Manifest.permission.CALL_PHONE),
                            CALL_OUT_REQUEST_CODE
                        )
                        Log.d("Howard","requestPermissions")
                    false
                }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        callOutBtn.setOnClickListener {
            if (checkPermissions()){
                callOut()
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        when(requestCode){
            CALL_OUT_REQUEST_CODE ->{
                   if (grantResults.isNotEmpty() &&
                       grantResults[0] ==
                       PackageManager.PERMISSION_GRANTED    ){
                       callOut()
                   }else{
                       //如果勾選不在詢問後 會顯示訊息 提醒的方法
                       //ActivityCompat.shouldShowRequestPermissionRationale
                       //以下狀態都沒發生時
                       // shouldShowRequestPermissionRationale 後會回傳 false
                       //呼叫requestPermissions後會回傳 true
                       //勾選不在詢問回傳 false
                       if (!ActivityCompat.
                               shouldShowRequestPermissionRationale(
                                   this,Manifest.permission.CALL_PHONE) ){
                           AlertDialog.Builder(this).
                               setTitle("開啟權限").
                               setMessage(R.string.permission_msg).show()
//                                Toast.makeText(this,
//                                    R.string.permission_msg,
//                                    Toast.LENGTH_LONG).show()
                       }
                   }
            }
        }

    }
}
