package tw.com.xvpower.ch2_1_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    private fun calculate(number1EditText: EditText,
                          number2EditText: EditText,viewID:Int):Int{
        //with 最終回傳字串類型
        //this 表示目前字串
        val str = number1EditText.text.toString()
        val  n1Str =with(number1EditText.text.toString()){
            //檢查輸入數字是否為空白
                if (isNotEmpty()) this else "0"
        }

        val  n2Str =with(number2EditText.text.toString()){
            //檢查輸入數字是否為空白
             if (isNotEmpty()){
                    //處理除法分母為零
                  if (viewID==R.id.divsionBtn && this == "0"){
                        "1"
                  }else{
                      this
                  }
             }
             //處理除法分母為空白
             else if (viewID==R.id.divsionBtn) "1"
             else "0"
        }

       val ans =  when(viewID){
            R.id.pluseBtn->n1Str.toInt() + n2Str.toInt()
            R.id.minusBtn->n1Str.toInt() - n2Str.toInt()
            R.id.multipBtn->n1Str.toInt() * n2Str.toInt()
            R.id.divsionBtn->n1Str.toInt() / n2Str.toInt()
            else ->0
        }
        Toast.makeText(this,ans.toString(),
            Toast.LENGTH_SHORT).show()
        Log.d("Howard",ans.toString())
        return ans
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        pluseBtn.setOnClickListener {
            calculate(numberTest1, numberTest2,it.id) }
        minusBtn.setOnClickListener {
            calculate(numberTest1, numberTest2,it.id) }
        multipBtn.setOnClickListener {
            calculate(numberTest1, numberTest2,it.id) }
        divsionBtn.setOnClickListener {
            calculate(numberTest1, numberTest2,it.id)  }
    }
}
