package tw.com.xvpower.ch2_2_java_activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    //直向變橫向時也會重新呼叫onCreate
    //橫向變直向時也會重新呼叫onCreate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //取得元件
        //數值初始化
        setContentView(R.layout.activity_main);
        String age = getString(R.string.age);
        Log.d("Howard",age);
        Log.d("Howard","onCreate");
        Calendar calendar =  Calendar.getInstance();
       int h =  calendar.get(Calendar.HOUR_OF_DAY);
       int m =  calendar.get(Calendar.MINUTE);
       int s =  calendar.get(Calendar.SECOND);
       Log.d("Howard",h+":"+m+":"+s);

    }


    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d("Howard","onRestart");
        //恢復連線關閉狀態
    }


    @Override
    protected void onStart() {
        super.onStart();
        Log.d("Howard","onStart");
        //onStart 可顯示時　會在螢幕上顯示資訊
        //畫面相關設定　顏色　大小
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("Howard","onResume");
        //onResume 可控制狀態
        //啟動GPS 開始運行遊戲等等.....
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.d("Howard","onPause");
        //onResume 暫時不可控制狀態
        //快速佔存資料
        //GPS連線可關閉
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.d("Howard","onStop");
        //onResume 暫時不可控制狀態　也無顯示
        // 可使用持久性儲存，儲存目前資料ex:(SQLlite,File)
        //網路連線可關閉　藍芽連線
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.d("Howard","onDestroy");
        //Activity結束了
        //清空資源　與關閉連線等等
    }
}
