package tw.com.xvpower.ch2_1_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static final int PLUSE = 100;
    public static final int MINUS = 101;
    public static final int MULIP = 102;
    public static final int DIVSION = 103;

    private int calculateBySwitchConstant(int action, int number1, int number2) {
        int asn = 0;
        switch (action) {
            case PLUSE:
                asn = number1 + number2;
                break;
            case MINUS:
                asn = number1 - number2;
                break;
            case MULIP:
                asn = number1 * number2;
                break;
            case DIVSION:
                asn = number1 / number2;
                break;
        }
        return asn;
    }

    private int calculateBySwitchViewId(int id, int number1, int number2) {
        int asn = 0;
        switch (id) {
            case R.id.pluseBtn:
                asn = number1 + number2;
                break;
            case R.id.minusBtn:
                asn = number1 - number2;
                break;
            case R.id.multipBtn:
                asn = number1 * number2;
                break;
            case R.id.divsionBtn:
                asn = number1 / number2;
                break;
        }
        return asn;
    }

    private void calculate(EditText number1Et, EditText number2Et, int action) {
        String n1 = number1Et.getText().toString();
        String n2 = number2Et.getText().toString();
        int number1 = Integer.parseInt(n1);
        int number2 = Integer.parseInt(n2);
        //使用常數解決方案
        int asn = calculateBySwitchConstant(action, number1, number2);
        Toast.makeText(MainActivity.this, String.valueOf(asn),
                Toast.LENGTH_LONG).show();
    }

    private void calculate2(EditText number1Et, EditText number2Et, int viewId) {
        String n1 = number1Et.getText().toString();
        String n2 = number2Et.getText().toString();
        int number1 = Integer.parseInt(n1);
        int number2 = Integer.parseInt(n2);
        //使用ViewId的解決方案
        int asn = calculateBySwitchViewId(viewId, number1, number2);
        Toast.makeText(MainActivity.this, String.valueOf(asn),
                Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText number1 = findViewById(R.id.numberTest1);
        final EditText number2 = findViewById(R.id.numberTest2);
        Button btn = findViewById(R.id.pluseBtn);
        Button btn2 = findViewById(R.id.minusBtn);
        Button btn3 = findViewById(R.id.multipBtn);
        Button btn4 = findViewById(R.id.divsionBtn);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //calculate(number1,number2,PLUSE);
                calculate2(number1, number2, v.getId());
            }
        });

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calculate(number1,number2,MINUS);
                calculate2(number1, number2, v.getId());
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calculate(number1,number2,MULIP);
                calculate2(number1, number2, v.getId());
            }
        });

        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calculate(number1,number2,DIVSION);
                calculate2(number1, number2, v.getId());
            }
        });

    }
}
