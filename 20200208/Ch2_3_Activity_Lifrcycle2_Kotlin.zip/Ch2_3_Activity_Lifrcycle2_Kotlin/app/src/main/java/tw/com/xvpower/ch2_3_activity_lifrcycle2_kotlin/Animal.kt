package tw.com.xvpower.ch2_3_activity_lifrcycle2_kotlin

import android.util.Log

class Animal {
    var age:Int=0
    //在類型加上?表示可給予null
    var name:String?=null
    get() {
        Log.d("Howard","get Name")
        return field
    }
    set(value) {
        Log.d("Howard","set Name")
        field = value
    }

    constructor(name:String="",age:Int=0){
        this.name = name
        this.age = age
    }
}