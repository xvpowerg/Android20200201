package tw.com.xvpower.ch2_3_activity_lifrcycle2_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import java.util.Calendar
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
       val obj:Animal =  Animal()
        obj.name = "Ken"
        Log.d("Howard","onCreate test ${obj.name} ${obj.age}")
    }
    override fun onStart() {
        super.onStart()
        val cal = Calendar.getInstance()
        val h = cal.get(Calendar.HOUR_OF_DAY)
        val m = cal.get(Calendar.MINUTE)
        val s = cal.get(Calendar.SECOND)
        val time = "%02d:%02d:%02d".format(h,m,s)
        timeView.text =time
    }
}
