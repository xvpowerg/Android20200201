package tw.com.xvpower.ch2_3_acticity_lifecycle2_java;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.Calendar;


public class MainActivity extends AppCompatActivity {
    private TextView timeView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        timeView =  findViewById(R.id.timeView);

    }

    @Override
    protected void onStart() {
        super.onStart();
        Calendar calendar =   Calendar.getInstance();
        int h = calendar.get(Calendar.HOUR_OF_DAY);
        int m = calendar.get(Calendar.MINUTE);
        int s = calendar.get(Calendar.SECOND);
        String time = String.format("%02d:%02d:%02d",h,m,s);
        timeView.setText(time);
    }
}
