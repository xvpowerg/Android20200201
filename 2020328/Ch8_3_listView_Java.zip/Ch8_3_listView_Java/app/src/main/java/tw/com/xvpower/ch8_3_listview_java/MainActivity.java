package tw.com.xvpower.ch8_3_listview_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        List<String> nameList = new ArrayList();
        nameList.add("Ken");
        nameList.add("Vivin");
        nameList.add("Lindy");
        nameList.add("Joey");
        ListView listView = findViewById(R.id.nameList);
        ArrayAdapter<String> arrayAdapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        android.R.id.text1,
                        nameList);
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener((parent, view, position, id) -> {
                    Log.d("Howard","position:"+nameList.get(position));
        });

      ListView imageList =   findViewById(R.id.imageListView);
        List<Map<String,Object>> simpleList = new ArrayList<>();
        final String IMAGE_NAME = "imageName";
        final String IMAGE_RES = "imageRes";

        for (int i = 1; i <= 9;i++){
            String imageKey = "image"+i;
            Map map1 = new HashMap();
            try{
               Field field= R.drawable.class.getField(imageKey);
                map1.put(IMAGE_NAME,imageKey);
                map1.put(IMAGE_RES,field.get(null));
                simpleList.add(map1);
            }catch (NoSuchFieldException | IllegalAccessException ex){
                Log.d("Howard","ex:"+ex);
            }
        }
        
        SimpleAdapter sa = new SimpleAdapter(this,
                simpleList,R.layout.image_list_view,
                new String[]{IMAGE_NAME,IMAGE_RES},new int[]{
                    R.id.imageListTxt,
                    R.id.imageListImgView
                });
        imageList.setAdapter(sa);

    }
}
