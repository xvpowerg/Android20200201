package tw.com.xvpower.ch8_1_spinner_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.core.text.isDigitsOnly
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val priceList = mutableListOf<Int>(10,20,30)
        val list = mutableListOf<String>("Banana","Kiwi","Apple")
        //Banana 10
        //Kiwi 20
        //Apple 30
       val adapter =  ArrayAdapter(this,
               android.R.layout.simple_list_item_1,
               android.R.id.text1,list)
        spinner.adapter = adapter
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("Howard","Empty")
            }

            override fun onItemSelected(parent: AdapterView<*>?, view: View?,
                                        position: Int, id: Long) {
                Log.d("Howard","Fruit:${list[position]} Price:${priceList[position]}")
            }
        }

        comitBtn.setOnClickListener {
            val name = fruitNameTxt.text.toString()
            val price = fruitPriceTxt.text.toString()
            if (name.isEmpty() || price.isEmpty()){
                    Toast.makeText(this,"name or price can't  empty",
                        Toast.LENGTH_SHORT).show()
            }else if(price.isDigitsOnly()){
                list.add(name)
                priceList.add(price.toInt())
                Log.d("Howard","$name $price");
                Toast.makeText(this,"success full !",
                    Toast.LENGTH_SHORT).show()
                fruitNameTxt.text.clear()
                fruitPriceTxt.text.clear()
            }else{
                Toast.makeText(this,"price only input Digits!",
                    Toast.LENGTH_SHORT).show()
            }

        }
        //臺北市 264.6 萬
        //新北市 401.5 萬
        //桃園市 224.5 萬
        //臺中市 281.5 萬
        //臺南市 188.1 萬
        //高雄市 277.3 萬
        val  city = "臺北市、新北市、桃園市、臺中市、臺南市、高雄市"
        val popArray = arrayOf(264.6,401.5 ,224.5,281.5,188.1,277.3);
        val cityArray = city.split("、")
        val cityAdapter = ArrayAdapter(this,
            R.layout.sprinner_layout,
        R.id.spinner2Txt,cityArray)
        spinner2.adapter =cityAdapter
        spinner2.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {
                Log.d("Howard","Empty!");
            }

            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View?,
                position: Int,
                id: Long
            ) {
                populationTxt.text = "人口數:${popArray[position]} 萬"

            }

        }

    }
}
