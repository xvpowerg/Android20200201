package tw.com.xvpower.ch8_2_completetext;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;

import java.lang.reflect.Field;
import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       String[] imagesTxt =   getResources().getStringArray(R.array.images);
        AutoCompleteTextView aucv = findViewById(R.id.autoCompleteTextView);
         ImageView imageView =  findViewById(R.id.imageView);
        HashMap<String,Integer> imageMap = new HashMap<>();
        for (String imageKey : imagesTxt){
            try{
                //反射
                Field field =    R.drawable.class.getField(imageKey);
                imageMap.put(imageKey,field.getInt(null));
            }catch (NoSuchFieldException ex){
                Log.d("Howard","NoSuchFieldException:"+ex);
            }catch(IllegalAccessException ex){
                Log.d("Howard","IllegalAccessException:"+ex);
            }

        }
//        imageMap.put("image1",R.drawable.image1);
//        imageMap.put("image2",R.drawable.image2);
//        imageMap.put("image3",R.drawable.image3);
//        imageMap.put("image4",R.drawable.image4);
//        imageMap.put("image5",R.drawable.image5);
//        imageMap.put("image6",R.drawable.image6);
//        imageMap.put("image7",R.drawable.image7);
//        imageMap.put("image8",R.drawable.image8);
//        imageMap.put("image9",R.drawable.image9);

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R
        .layout.simple_dropdown_item_1line,
                android.R.id.text1,
                imagesTxt);
        aucv.setAdapter(arrayAdapter);
        aucv.setThreshold(1);
        aucv.setOnItemClickListener((p,v,pos,id)->{

          String name =   p.getItemAtPosition(pos).toString();
            imageView.setImageResource(imageMap.get(name));
            Log.d("Howard","P:"+name);
        });
    }
}
