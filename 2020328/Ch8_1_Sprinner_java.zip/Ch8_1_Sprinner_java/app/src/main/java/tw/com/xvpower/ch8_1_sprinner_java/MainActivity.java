package tw.com.xvpower.ch8_1_sprinner_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       // String[] names = {"Ken","Vivin","Lindy"};
       final  String[] names = getResources().getStringArray(R.array.my_name);
        //String[] names = {};
          //String namesStr =  getString(R.string.names);
        //  String[] names = namesStr.split(",");
        ArrayAdapter<String> arrayAdap = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                android.R.id.text1,
                names);

        Spinner spinner =  findViewById(R.id.spinner);
        spinner.setAdapter(arrayAdap);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Howard","position:"+names[position]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d("Howard","Empty");
            }
        });
    }

}
