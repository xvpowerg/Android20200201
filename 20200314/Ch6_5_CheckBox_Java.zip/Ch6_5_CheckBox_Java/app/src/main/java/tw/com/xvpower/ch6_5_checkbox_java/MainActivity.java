package tw.com.xvpower.ch6_5_checkbox_java;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       CheckBox cBox1 =  findViewById(R.id.checkBox1);
       CheckBox cBox2 =   findViewById(R.id.checkBox2);
       CheckBox cBox3 =   findViewById(R.id.checkBox3);
       CheckBox cBox4 =   findViewById(R.id.checkBox4);
       CheckBox cBox5 =   findViewById(R.id.checkBox5);
       Button btn =  findViewById(R.id.submitBtn);
      final CheckBox[] checkBoxs = {cBox1,cBox2,cBox3,cBox4,cBox5};

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder sb = new StringBuilder();
                for (CheckBox cb : checkBoxs){
                    if (cb.isChecked()){
                        sb.append(cb.getText());
                        sb.append(" ");
                    }
                }
                Toast.makeText(MainActivity.this, sb.toString(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        cBox1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                Log.d("Howard","isChecked:"+isChecked);
            }
        });

    }
}
