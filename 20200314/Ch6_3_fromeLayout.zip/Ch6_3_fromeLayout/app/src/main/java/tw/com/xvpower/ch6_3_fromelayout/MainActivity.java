package tw.com.xvpower.ch6_3_fromelayout;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private boolean isShowHeartVisible = false;
    private boolean isShowNumberVisible = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final Button heartBtn = findViewById(R.id.heartBtn);
        final Button numberBtn =  findViewById(R.id.numberBtn);
        final ImageView heart = findViewById(R.id.heart);
        final ImageView number1 = findViewById(R.id.number1);

        numberBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {

                if (isShowNumberVisible){
                    numberBtn.setText(R.string.gone_number1);
                    number1.setVisibility(View.VISIBLE);
                }else{
                    numberBtn.setText(R.string.visible_number1);
                    number1.setVisibility(View.GONE);
                }

                isShowNumberVisible = !isShowNumberVisible;
            }
        });

        heartBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isShowHeartVisible){
                    heartBtn.setText(getString(R.string.gone_heart));
                    heart.setVisibility(View.VISIBLE);
                }else{
                    heartBtn.setText(getString(R.string.visible_heart));
                    heart.setVisibility(View.INVISIBLE);
                }
                isShowHeartVisible = !isShowHeartVisible;

            }
        });
    }
}
