package tw.com.xvpower.ch6_5_checkbox_ckeckdall_kotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.CompoundButton
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val checkBoxArray = arrayOf(checkBox1,checkBox2,checkBox3,checkBox4)

        val unCheckAllBox = { buttonView: View ->
            val checkBox = buttonView as CheckBox
             val isChecked =  checkBox.isChecked
                if (!isChecked){
                    checkBoxAll.isChecked = false
                }else{
                    var allChecked = true
                    for (box in checkBoxArray){
                        if (!box.isChecked){
                            allChecked = false
                           break
                        }
                    }
                   checkBoxAll.isChecked = allChecked
                }
        }


        for ( box in checkBoxArray){
            box.setOnClickListener (unCheckAllBox)
        }
        checkBoxAll.setOnClickListener {
                buttonView ->
            val  allbox =  buttonView as CheckBox;

                for (box in checkBoxArray){
                    box.isChecked =allbox.isChecked
                }
        }


    }
}
