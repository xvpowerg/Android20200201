package tw.com.xvpower.ch6_4_textview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       final CheckedTextView checkView =  findViewById(R.id.checkedText1);
        final CheckedTextView checkView2 =  findViewById(R.id.checkedText2);
        final CheckedTextView checkView3 =  findViewById(R.id.checkedText3);
        final CheckedTextView[] checkViews = {checkView,checkView2,checkView3};
        final Button submitBtn =  findViewById(R.id.submitBtn);

        View.OnClickListener  click = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CheckedTextView  ct = (CheckedTextView)v;
                ct.toggle();
            }
        };


        for (CheckedTextView ctv : checkViews){
            ctv.setOnClickListener(click);
        }

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuilder sb = new  StringBuilder();
                for (CheckedTextView cv : checkViews){
                        if (cv.isChecked()){
                           String msg = cv.getText().toString();
                            sb.append(msg);
                            sb.append(" ");
                        }
                }

                Toast.makeText(MainActivity.
                        this,sb.toString(),Toast.LENGTH_SHORT).show();

            }
        });
        //checkView.setOnClickListener(ckick);
    }
}
