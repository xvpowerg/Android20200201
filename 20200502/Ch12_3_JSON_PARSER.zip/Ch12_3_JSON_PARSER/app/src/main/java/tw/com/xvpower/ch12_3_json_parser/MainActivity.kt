package tw.com.xvpower.ch12_3_json_parser

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_main.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private fun parserJsonObject(){
                val jsonObject = "{name:\"Ken\" ,age:18}"
        Log.d("Howard","jsonObject:$jsonObject")
        val  jsonObj =  JSONObject(jsonObject)
        val name = jsonObj.getString("name")
        val age = jsonObj.getInt("age")
        Log.d("Howard","name:$name age:$age")
    }

    private fun parserJsonArray(){
        val jsonArrayStr = "[\"A\",10,\"Ken\",5.71]"
        val jsonArray = JSONArray(jsonArrayStr)
        val v1 =   jsonArray.getString(0)
       val v2 =  jsonArray.getInt(1)
        val v3 =  jsonArray.getString(2)
        val v4 = jsonArray.getDouble(3)
        Log.d("Howard","$v1,$v2,$v3,$v4")
    }
    private fun parserJsonMix(){
        val jsonMixStr = "{country:\"Taipei\",hobby:[\"Play Game\",\"Music\",\"Drawing\"] }"
            val jsonObj = JSONObject(jsonMixStr)
       val  country = jsonObj.getString("country")
        val jsonArray = jsonObj.getJSONArray("hobby")
        Log.d("Howard","country $country")
        for (i   in 0 until jsonArray.length()){
            Log.d("Howard","hobby ${jsonArray.getString(i)}")
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        parserObjectBtn.setOnClickListener {
            parserJsonObject()
        }
        parserArrayBtn.setOnClickListener {
            parserJsonArray()
        }
        parseMixBtn.setOnClickListener {
            parserJsonMix()

        }
    }
}
