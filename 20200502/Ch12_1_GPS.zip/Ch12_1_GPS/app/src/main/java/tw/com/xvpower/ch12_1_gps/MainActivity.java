package tw.com.xvpower.ch12_1_gps;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity  {
    //管理GPS的API
    private LocationManager locationManager = null;
    private LocationListener locationListener;

    private class MyLocationListener implements LocationListener{
            private TextView textView;
                private MyLocationListener(TextView textView){
                    this.textView = textView;
                }
        //根據設定決定 多少時間間隔 取得一次目前位置 或是 用距離
        @Override
        public void onLocationChanged(Location location) {
            textView.setText("經度:"+location.getLongitude()+
                    "緯度:"+location.getLatitude());
//            Log.d("Howard","經度:"+location.getLongitude()+
//                    "緯度:"+location.getLatitude());
            //location.getLatitude()緯度
           // location.getLongitude();//經度
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    }

//讓使用者確定 開啟GPS權限
    private void checkGSPPermission(){
        if (ContextCompat.
                checkSelfPermission(this,
                        Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED){
            addLocationListener();
        }else{
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    100);
        }
    }

    @SuppressLint("MissingPermission")
    private  void addLocationListener(){
        //minTime 單位毫秒
        //minDistance 單位公尺
        locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,
                3000,0f,locationListener);
        locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER,
                3000,0f,locationListener);
    }

    private void initLocationManager(){
        if (locationListener == null){
            locationManager =
                    (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            TextView gpsInfoTxt = findViewById(R.id.gpsInfoTxt);
            locationListener = new MyLocationListener(gpsInfoTxt);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initLocationManager();
    }
    @Override
    protected void onResume() {
        super.onResume();
        initLocationManager();
        checkGSPPermission();

    }

    //解除註冊
    @Override
    protected void onPause() {
        super.onPause();
        locationManager.removeUpdates(locationListener);
        locationListener = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
            if (requestCode != 100) return;
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED){
                initLocationManager();
                addLocationListener();
            }
    }
}
