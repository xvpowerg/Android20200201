package com.example.ch1_2_testproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //可找到我要的Button
       Button btn =  findViewById(R.id.showToastBtn);
       //OnClickListener 創造一個監聽器
        //監聽器作用:Button 按下時呼叫 此監聽器onClick方法
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,
                        "Msg!!",Toast.LENGTH_LONG).show();
          }
        });

    }
}
