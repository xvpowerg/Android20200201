package tw.com.xvpower.testalert;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private String myAccount = "qwer";
    private String password = "12345";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       Button baseBtn =  findViewById(R.id.baseDialogBtn);
       Button inputBtn =  findViewById(R.id.inputDialogBtn);
        TextView msgTxt = findViewById(R.id.msgTxt);
       baseBtn.setOnClickListener(e->{
           AlertDialog.Builder builder =
                   new  AlertDialog.Builder(this) ;
           builder.setTitle("Titile").setMessage("Message").
                   setCancelable(false).
                   setPositiveButton("確定",(d,w)->{msgTxt.setText("狀態為確定");}).
                   setNegativeButton("取消",(d,w)->{msgTxt.setText("狀態為取消");}).
                   setNeutralButton("關於我",(d,w)->{msgTxt.setText("版本1.0");}).show();
       });

        inputBtn.setOnClickListener(e->{

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            EditText accountET = new EditText(this);
            accountET.setHint("帳號");
            EditText passET = new EditText(this);
            passET.setHint("密碼");
            passET.setInputType(InputType.TYPE_CLASS_TEXT
                    |InputType.TYPE_TEXT_VARIATION_PASSWORD);
            LinearLayout layout = new LinearLayout(this);
            layout.setOrientation(LinearLayout.VERTICAL);
            layout.addView(accountET);
            layout.addView(passET);
            
            builder.setTitle("請輸入帳號密碼").setView(layout).
                    setPositiveButton("確定",(d,w)->{
                       String account =  accountET.getText().toString();
                        String pass = passET.getText().toString();
                        if (account.equals(myAccount) &&
                                password.equals(pass)){
                            msgTxt.setText("登入成功");
                        }else{
                            msgTxt.setText("登入失敗");
                        }
                    }).show();
        });


    }
}
