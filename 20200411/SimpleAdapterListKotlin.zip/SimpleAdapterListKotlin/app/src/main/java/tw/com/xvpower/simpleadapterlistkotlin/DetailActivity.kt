package tw.com.xvpower.simpleadapterlistkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import kotlinx.android.synthetic.main.activity_detail.*

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
       val product =  intent.getParcelableExtra<Product>("product")
        product?.run {
            deatilNameTxt.text = name
            itemImage.setImageResource(img)
            priceTxt.text="${priceTxt.text}:$price"
            sizeTxt.text = "H $h , W:$w"
        }
        Log.d("Howard","product:$product")
    }
}
