package tw.com.xvpower.simpleadapterlistkotlin

import android.os.Parcel
import android.os.Parcelable

data class Product(val name:String?,val img:Int,val price:Int,val h:Float,val w:Float):Parcelable {
    constructor(parcel: Parcel) : this(
        parcel.readString(),
        parcel.readInt(),
        parcel.readInt(),
        parcel.readFloat(),
        parcel.readFloat()
    ) {
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(name)
        parcel.writeInt(img)
        parcel.writeInt(price)
        parcel.writeFloat(h)
        parcel.writeFloat(w)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<Product> {
        override fun createFromParcel(parcel: Parcel): Product {
            return Product(parcel)
        }

        override fun newArray(size: Int): Array<Product?> {
            return arrayOfNulls(size)
        }
    }
}

