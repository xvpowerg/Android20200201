package tw.com.xvpower.testdialogkotlin

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

class FruitBaseAdapter(val list:List<Fruit>,val context:Context) : BaseAdapter() {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
      val view =
          LayoutInflater.from(context).inflate(R.layout.fruit_layout,parent,false)

        val name = view.findViewById<TextView>(R.id.fruitNameTxt)
        val price = view.findViewById<TextView>(R.id.fruitPriceTxt)
       val fruit =  getItem(position)
        name.text = fruit.name
        price.text = fruit.price.toString()
        return view
    }

    override fun getItem(position: Int): Fruit {
        return list[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getCount(): Int {
        return list.size
    }
}