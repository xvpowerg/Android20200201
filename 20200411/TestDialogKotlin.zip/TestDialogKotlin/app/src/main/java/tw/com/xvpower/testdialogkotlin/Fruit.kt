package tw.com.xvpower.testdialogkotlin

data class Fruit(val name:String,val price:Float) {
}