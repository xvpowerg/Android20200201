package tw.com.xvpower.testdialogkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    fun listDialogBtn1(){
        val listAdapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1,
            android.R.id.text1, listOf("Apple","Banana","Cherry"))
        listDialogBtn.setOnClickListener {
            AlertDialog.Builder(this).
            setTitle("產品清單").
            setAdapter(listAdapter){
                    dialog, which ->Log.d("Howard","which: $which")
                val msg =  listAdapter.getItem(which)
                msgTxt.text = msg
            }.show();
        }
    }

    fun listDialogBtn2(){
        val list = listOf(Fruit("Apple",10f),Fruit("Banana",15f),
            Fruit("Cherry",21f))
        val  fba =  FruitBaseAdapter(list,this)
        listDialogBtn2.setOnClickListener {
            Log.d("Howard","test!!!")
            AlertDialog.Builder(this).setTitle("產品清單").
            setAdapter(fba){dialog, which ->
                val f = fba.getItem(which)
                msgTxt.text ="${f.name} : ${f.price}"
            }.show()
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        listDialogBtn1()
        listDialogBtn2()

    }
}
