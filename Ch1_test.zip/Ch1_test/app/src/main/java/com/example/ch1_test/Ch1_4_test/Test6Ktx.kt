package com.example.ch1_test.Ch1_4_test

fun main(args: Array<String>) {
//    TestNull().compare("A","GX")
//    TestNull().compare(null,"GX")
    //? 意思 這個變數之後不會變為null
    //這時 Kotlin 就不檢查數值是否為null
    var str1:String? = null
    var str2:String = "Vivin"

//    if (str1 != null){
//        val cmp = str1.compareTo(str2)
//    }

    //? 假設str1為null就不執行compareTo
    //以下語法與上面的if (str1 != null) 依樣
    val cmp = str1?.compareTo(str2)

    println(cmp)


}