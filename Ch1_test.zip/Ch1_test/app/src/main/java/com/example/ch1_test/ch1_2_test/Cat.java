package com.example.ch1_test.ch1_2_test;

public class Cat extends Animal {
    public void jump(){
        System.out.println("Cat Jump!!");
    }
}
