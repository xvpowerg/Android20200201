package com.example.ch1_test.Ch1_5_test
    //預設讀取權限都是final public
    fun testAbs( op1:Int):Int{
        var ans = op1
        if (ans < 0){
            ans *= -1
        }
        return ans
    }
//因為if 可回傳數值 所可用以下寫法
fun testAbs2( op1:Int):Int{
    return if (op1 < 0) op1 * -1 else  op1
}

fun setColor(r:Int=0,g:Int=0,b:Int=0){
    println("R:$r G:$g B$b")
}

fun String.toSplitStLen(delimiters:String):List<Int>{
   val list:List<String> =  this.split(delimiters)
    return list.map {it.length }
}

fun main(args: Array<String>) {
//  val ans=  testAbs(20)
//    println(ans)
//    setColor(1,30,50)
//    setColor(r=71,g=30)
//    setColor(g=30)

    val nameList:String = "Ken,Vivin,Lindy"
    val listLen =  nameList.toSplitStLen(",")
    listLen.forEach {
        println("len:$it") }

}