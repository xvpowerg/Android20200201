package com.example.ch1_test.Ch1_3_test

fun main(args: Array<String>) {
//    val names:Array<String> = arrayOf("Ken","Vivin","Lindy")
//    for (n in names){
//        println(n)
//    }

    //這裡的it指的是 Array方法的最後一個參數，Lamdba語法的 傳入數值
    //目前傳入數值指的是 index
    val evenNumber = Array(16){
       // println(it)
        it * 2
    }
    for (n in evenNumber){
        println("Value:$n")
    }

    println(evenNumber[3])
    evenNumber[7] = 91
    println( evenNumber[7])


   val array =  Array(3){
        "Value:$it"
    }
    for(v in array){
        println(v)
    }

    //整數陣列 可以是用intArrayOf
    //可給予初始值
    val myIntArray1 =intArrayOf(30,60,70)

    //產生一組長度為10的整數陣列
    //所有陣列預設數值為0
   val myIntArray2 =  IntArray(10)

    println(myIntArray1[2])
    println(myIntArray2[1])
    myIntArray2[1] = 73
    println(myIntArray2[1])
    println(myIntArray2[1].plus(5))
    println(myIntArray2[1])

}