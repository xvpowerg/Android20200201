package com.example.ch1_test.Ch1_6_test
fun main(args: Array<String>) {
    //每次累加1
    for (i in 1..10){
        print(" $i")
    }
    //每次累加4
    println("")
    for (n in 1..20 step 4){
        print(" $n")
    }
    //每次累減1
    println("")
    for (n in 20 downTo 5){
        print("$n ")
    }
    //每次累減3
    println("")
    for (n in 20 downTo 5 step 3){
        print("$n ")
    }
    //出現0~8
    val len:Int = 9
    println("")
    for (n in 0 until len){
        print(" $n")
    }


    //每次累加1 加上break
    println("")
    for (i in 0..10){
        if (i == 5){
            break
        }
        print(" $i")
    }

}