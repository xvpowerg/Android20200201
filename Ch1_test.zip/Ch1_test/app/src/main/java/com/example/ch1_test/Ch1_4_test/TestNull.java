package com.example.ch1_test.Ch1_4_test;

public class TestNull {
        public void compare(String s1 ,String s2){
            if (s1 != null && s2 != null){
                if (s1.compareTo(s2) == 0){
                    System.out.println("一樣");
                }else if(s1.compareTo(s2) < 0){
                    System.out.println(s1+"小於"+s2);
                }else{
                    System.out.println(s1+"大於"+s2);
                }
            }
        }
}
