package com.example.ch1_test

fun main(args: Array<String>) {
    //宣告變數
    println("Hello!!")
    var t1 = 10
    var t2:Int = 20
    var t3:String = "Test1"
    //常數
    val t4:Long = 2657
    val t5:Float = 2.789f

    val title:String = "Title:"
    val name:String = "Ken"
    //$ 放在字串中表示為一個變數
    val ans = "$title$name"
    println(ans)

}