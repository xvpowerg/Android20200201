package com.example.ch1_test;

public class TestEqualsJava {

    public void testStringEquals(){
        String st1 = newString();
        String st2 = newString();
        System.out.println(st1 == st2);
        System.out.println(st1.equals(st2) );
    }

    public String newString(){
        return new String("A");
    }
}
