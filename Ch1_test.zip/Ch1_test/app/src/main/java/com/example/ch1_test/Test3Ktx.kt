package com.example.ch1_test

fun main(args: Array<String>) {
    //創造一個TestEqualsJava 物件
  //  TestEqualsJava().testStringEquals()

    val s1 =  TestEqualsJava().newString()
    val s2 =  TestEqualsJava().newString()
    //Kotlin ==會呼叫equals
    println(s1 == s2)
    //Kotlin 呼叫===才會比較記憶體位置
    println(s1 === s2)


}