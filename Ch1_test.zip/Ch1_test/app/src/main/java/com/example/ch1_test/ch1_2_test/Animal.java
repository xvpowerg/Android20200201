package com.example.ch1_test.ch1_2_test;

public class Animal {
    public void bark(){
        System.out.println("Animal bark....");
    }

}
