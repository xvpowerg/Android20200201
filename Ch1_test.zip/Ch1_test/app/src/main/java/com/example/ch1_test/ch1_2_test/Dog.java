package com.example.ch1_test.ch1_2_test;

public class Dog extends Animal{
    public void eat(){
        System.out.println("Dog eat!!!");
    }
}
