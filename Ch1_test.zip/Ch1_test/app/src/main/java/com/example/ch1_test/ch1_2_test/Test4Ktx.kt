package com.example.ch1_test.ch1_2_test

fun main(args: Array<String>) {

    val dog1:Animal = Cat()

//    if (dog1 is Dog){
//        println(dog1.eat())
//    }
    val dog2 = dog1 as Dog
    dog2.eat()
}