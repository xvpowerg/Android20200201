package com.example.ch1_test.Ch1_7

fun main(args: Array<String>) {
    //val v = if(2 < 5) "A" else "B"

//    val action = 2
//    when(action)
//    {
//        1 -> println("跑")
//        2 -> println("跳")
//        3 ->println("走")
//        else ->println("Error!")
//    }

    val score = 100
   val level = when(score){
        in 80..100  ->"A"
        in 70..79->"B"
        in 60.. 69->"C"
        in 0..50-> "D"
        else ->"Error"
    }
    println(level)
        /*
    100 - 80 A
    79 ~ 70 B
    69 ~60 C
    59~0 D
    other Error
          */
}