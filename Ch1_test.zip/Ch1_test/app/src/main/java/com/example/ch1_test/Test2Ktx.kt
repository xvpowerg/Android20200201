package com.example.ch1_test

fun main(args: Array<String>) {
    //來自於 java class
    val st1:Student = Student()
    st1.age =10
    st1.name = "Vivin"
    st1.printInfo()
}